<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\SlotController;
use App\Http\Controllers\TypeController;
use App\Http\Controllers\BrandController;
use App\Http\Controllers\TermsController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\RentalController;
use App\Http\Controllers\StatusController;
use App\Http\Controllers\ModeOfPaymentController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::group(['middleware' => ['api']], function () {

    Route::get("/getBranch", [BranchController::class, "get"]);
    Route::post("/manageBranch", [BranchController::class, "manage"]);
    
    Route::get("/getBrand", [BrandController::class, "get"]);
    Route::post("/manageBrand", [BrandController::class, "manage"]);
    
    Route::get("/getMode", [ModeOfPaymentController::class, "get"]);
    Route::post("/manageMode", [ModeOfPaymentController::class, "manage"]);
    
    Route::get("/getRental", [RentalController::class, "get"]);
    Route::post("/manageRental", [RentalController::class, "manage"]);
    
    Route::get("/getRole", [RoleController::class, "get"]);
    Route::post("/manageRole", [RoleController::class, "manage"]);
    
    Route::get("/getSlot", [SlotController::class, "get"]);
    Route::post("/manageSlot", [SlotController::class, "manage"]);
    Route::post("/deleteSlot", [SlotController::class, "delete"]);
    
    Route::get("/getStatus", [StatusController::class, "get"]);
    
    Route::get("/getType", [TypeController::class, "get"]);
    Route::post("/manageType", [TypeController::class, "manage"]);
    // Route::get("/getUom", [UomController::class, "get"]);
    Route::get("/getTypeSize/{id}", [TypeController::class, "getSize"]);
    Route::get("/manageTypeSize", [TypeController::class, "manageSize"]);

    Route::get("/get-terms",[TermsController::class,"get_terms"])->name("get_terms");
    Route::post("/edit-terms",[TermsController::class,"edit_terms"])->name("edit_terms");


});
<?php

namespace App\Http\Controllers;

use App\Models\Slot;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SlotController extends Controller
{
    public function get()
    {
        try {

        $data =  Slot::select(
            'cms_slot.id',
            'slot_number',
            'branch_id',
            'branch_name',
            'cms_slot.type_id',
            'type_name',
            'cms_slot.size',
            'cms_type_size.width',
            'cms_type_size.length',
            'cms_uom.uom_name',
            'cms_type.material',
            'brand_id',
            'brand_name',
            'cms_slot.status_id',
            'status_name',
            'cms_slot.created_at',
            'cms_slot.created_by',
            'cms_slot.updated_at',
            'cms_slot.updated_by'
        )
            ->leftJoin('cms_brand', 'cms_brand.id', '=', 'cms_slot.brand_id')
            ->join('cms_branch', 'cms_branch.id', '=', 'cms_slot.branch_id')
            ->join('cms_type', 'cms_type.id', '=', 'cms_slot.type_id')
            ->join('cms_status', 'cms_status.id', '=', 'cms_slot.status_id')
            ->join('cms_uom', 'cms_uom.id', '=', 'cms_type.uom_id')
            ->join('cms_type_size', 'cms_type_size.id', '=', 'cms_slot.size')
            ->get();

            return response()->json($data);

        } catch (\Exception $e) {

            return response($e, 500);

        }
    }

    public function manage(Request $request){

        try {
            $data = $request->all();
            $lastInsertId = 0;

            $slot = Slot::updateOrCreate([
                'id'   => $request->get('id'),
            ],[
                'slot_number'     => $data['slot_number'],
                'branch_id' => $data['branch_id'],
                'type_id'    => $data['type_id'],
                'size'    => $data['size'],
                'add_by'    => $data['add_by'],
                'status_id'   => $data['status_id']
            ]);

            $lastInsertId = $slot->id;
            return response(["id" => $lastInsertId, "status" => 'Sucess!'], 200);
        } catch (\Exception $e) {

            $errorCode = $e->errorInfo[1];

            if($errorCode == 1062){
                return response(["id" => $lastInsertId, "status" => false], 200);
            }else{
                return response($e, 500);
            }

        }

    }



    public function delete(Request $request){

        try {
            $data = $request->all();

            $deleted_at = ($data['status_id'] == 2) ? date("Y/m/d h:i:sa"): ' ';
            $deleted_by = ($data['status_id'] == 2) ? 'save user id':  ' ';
            $remarks = isset($data['remarks']) ? 'remarks':  ' ' ;
            
            $lastInsertId = 0;

            $slot = Slot::updateOrCreate([
                'id'   => $request->get('id'),
            ],[
                'status_id'   => 2,
                'remarks'   => $remarks,
                'deleted_by'   => $deleted_by,
                'deleted_at'   => $deleted_at
            ]);

            $lastInsertId = $slot->id;
            return response(["id" => $lastInsertId, "status" => 'Sucess!'], 200);
        } catch (\Exception $e) {

            DB::rollback();

            $errorCode = 'error message';

            if (isset($e->errorInfo[1])) {
                $errorCode = $e->errorInfo[1];
            }
            if($errorCode == 1062){
                return response(["id" => $lastInsertId, "status" => false], 200);
            }else{
                return response($e, 500);
            }

        }
        

    }
    

    public function testEdit()
    {
        foreach($request->data as $slot){
            Slot::where('id',$slot->id)->update(['slot_number' => $slot_no]);
        }

        return response()->json([
            'status' => true
        ]);
    }


    //
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Type extends Model
{
    use HasFactory;
    protected $table = 'cms_type';
    // protected $fillable = ['slot_number','branch_id','type_id','size','brand_id','status_id'];
    protected $guarded = [];
}

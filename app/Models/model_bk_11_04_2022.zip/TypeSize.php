<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TypeSize extends Model
{
    use HasFactory;

    // protected $guarded = [];

    protected $table = 'cms_type_size';
    
    protected $fillable = ['type_id','length','width','uom_id','status_id'];
}

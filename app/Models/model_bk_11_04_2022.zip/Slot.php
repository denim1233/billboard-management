<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Slot extends Model
{
    use HasFactory;
    protected $table = 'cms_slot';
    protected $fillable = ['slot_number','branch_id','type_id','size','brand_id','status_id'];
}
